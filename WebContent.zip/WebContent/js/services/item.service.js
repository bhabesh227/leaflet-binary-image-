(function () {
    'use strict';
 
    myModule
        .service('ItemService', ItemService);
 
    ItemService.$inject = ['$http', '$q'];
    
    function ItemService($http, $q) {
    	
    	var deferred = $q.defer();
    	
    	this.getItems = function() {
    		
    		return $http.get('js/items.json')
    			.then(function(response) {
    				
    				deferred.resolve(response.data);
    				return deferred.promise;
    				
    			}, function(response) {
    				
    				deferred.reject(response);				
    				return deferred.promise;
    			});
    	};

    }
})();